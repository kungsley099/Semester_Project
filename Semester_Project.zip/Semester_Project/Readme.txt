NAME:  OPPONG KINGSLEY

INDEX NUMBER: UEB3230722

CLASS : IT D

PROJECT DESCRIPTION:

   SEARCH ENGINE

This C++ program demonstrates a simple text search engine using a basic search index. It processes a collection of documents, preprocesses and indexes them, and then allows users to search for specific terms within the documents.
In this program, the user can search for any query that consists of one or more words. The search engine processes the query by tokenizing it into individual words, preprocesses each word by converting it to lowercase and removing punctuation, and then searches for documents that contain those processed words.

For example, if the user enters a query like "quick fox," the search engine will preprocess the query to "quick" and "fox." It will then search for documents containing either "quick" or "fox" (or both) in a case-insensitive manner. The search results will include documents that contain either or both of these words.