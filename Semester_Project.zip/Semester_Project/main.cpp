#include <iostream>
#include <vector>
#include <set>
#include <algorithm>
#include <sstream>

// Sample data
std::vector<std::string> documents;

void initializeSampleData() {
    documents.push_back("The quick brown fox jumps over the lazy dog.");
    documents.push_back("The quick brown fox jumps over the lazy cat.");
    documents.push_back("The quick brown dog jumps over the lazy cat.");
}

std::string preprocessText(const std::string& text) {
    std::string processedText = text;
    std::transform(processedText.begin(), processedText.end(), processedText.begin(), (int(*)(int))std::tolower);

    // Remove punctuation
    processedText.erase(std::remove_if(processedText.begin(), processedText.end(), (int(*)(int))std::ispunct), processedText.end());

    return processedText;
}

std::set<int> buildIndex(const std::vector<std::string>& documents) {
    std::set<int> index;
    for (int i = 0; i < documents.size(); i++) {
        std::string processedText = preprocessText(documents[i]);
        std::istringstream iss(processedText);
        std::string word;
        while (iss >> word) {
            index.insert(i);
        }
    }
    return index;
}

std::vector<std::string> search(const std::string& query, const std::set<int>& index, const std::vector<std::string>& documents) {
    std::string processedQuery = preprocessText(query);
    std::istringstream iss(processedQuery);
    std::string word;
    std::set<int> result;

    while (iss >> word) {
        if (result.empty()) {
            result = index;
        }

        std::set<int> tempResult;
        for (std::set<int>::iterator it = result.begin(); it != result.end(); ++it) {
            if (preprocessText(documents[*it]).find(word) != std::string::npos) {
                tempResult.insert(*it);
            }
        }

        result = tempResult;
    }

    std::vector<std::string> searchResults;
    for (std::set<int>::iterator it = result.begin(); it != result.end(); ++it) {
        searchResults.push_back(documents[*it]);
    }

    return searchResults;
}

int main() {
    // Initialize sample data
    initializeSampleData();

    // Build the search index
    std::set<int> index = buildIndex(documents);

    // Search for a query
    std::string query;
    std::cout << "Enter your search query: ";
    std::getline(std::cin, query);
    std::vector<std::string> results = search(query, index, documents);

    // Print the search results
    std::cout << "Search Results:\n";
    for (int i = 0; i < results.size(); i++) {
        std::cout << i + 1 << ". " << results[i] << "\n";
    }

    return 0;
}

